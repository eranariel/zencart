<?php
/**
 * @package admin
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: customers.php 6352 2007-05-20 21:05:01Z drbyte $
 */

define('HEADING_TITLE', 'לקוחות');

define('TABLE_HEADING_ID', 'ID#');
define('TABLE_HEADING_FIRSTNAME', 'שם פרטי');
define('TABLE_HEADING_LASTNAME', 'שם משפחה');
define('TABLE_HEADING_ACCOUNT_CREATED', 'תאריך יצירת החשבון');
define('TABLE_HEADING_LOGIN', 'כניסה אחרונה');
define('TABLE_HEADING_ACTION', 'פעולה');
define('TABLE_HEADING_PRICING_GROUP', 'קבוצת רכש');
define('TABLE_HEADING_AUTHORIZATION_APPROVAL', 'מאושר');
define('TABLE_HEADING_GV_AMOUNT', 'GV Balance');

define('TEXT_DATE_ACCOUNT_CREATED', 'חשבון נוצר:');
define('TEXT_DATE_ACCOUNT_LAST_MODIFIED', 'עדכון אחרון:');
define('TEXT_INFO_DATE_LAST_LOGON', 'כניסה אחרונה:');
define('TEXT_INFO_NUMBER_OF_LOGONS', 'מספר כניסות:');
define('TEXT_INFO_COUNTRY', 'מדינה:');
define('TEXT_INFO_NUMBER_OF_REVIEWS', 'מספר חוות דעת:');
define('TEXT_DELETE_INTRO', 'Are you sure you want to delete this customer?');
define('TEXT_DELETE_REVIEWS', 'Delete %s review(s)');
define('TEXT_INFO_HEADING_DELETE_CUSTOMER', 'Delete Customer');
define('TYPE_BELOW', 'Type below');
define('PLEASE_SELECT', 'Select One');
define('TEXT_INFO_NUMBER_OF_ORDERS', 'מספר הזמנות:');
define('TEXT_INFO_LAST_ORDER','הזמנה אחרונה:');
define('TEXT_INFO_ORDERS_TOTAL', 'סה"כ:');
define('CUSTOMERS_REFERRAL', 'הפניית לקוחות<br />קופון הנחה ראשון');
define('TEXT_INFO_GV_AMOUNT', 'יתרת GV');

define('ENTRY_NONE', 'None');

define('TABLE_HEADING_COMPANY','חברה');

define('CUSTOMERS_AUTHORIZATION', 'Customers Authorization Status');
define('CUSTOMERS_AUTHORIZATION_0', 'Approved');
define('CUSTOMERS_AUTHORIZATION_1', 'Pending Approval - Must be Authorized to Browse');
define('CUSTOMERS_AUTHORIZATION_2', 'Pending Approval - May Browse No Prices');
define('CUSTOMERS_AUTHORIZATION_3', 'Pending Approval - May browse with prices but may not buy');
define('CUSTOMERS_AUTHORIZATION_4', 'Banned - Not allowed to login or shop');
define('ERROR_CUSTOMER_APPROVAL_CORRECTION1', 'Warning: Your shop is set up for Approval with No Browse. The customer has been set to Pending Approval - No Browse');
define('ERROR_CUSTOMER_APPROVAL_CORRECTION2', 'Warning: Your shop is set up for Approval with Browse no prices. The customer has been set to Pending Approval - Browse No Prices');

define('EMAIL_CUSTOMER_STATUS_CHANGE_MESSAGE', 'Your customer status has been updated. Thank you for shopping with us. We look forward to your business.');
define('EMAIL_CUSTOMER_STATUS_CHANGE_SUBJECT', 'Customer Status Updated');

define('ADDRESS_BOOK_TITLE', 'Address Book Entries');
define('PRIMARY_ADDRESS', '(primary address)');
define('TEXT_MAXIMUM_ENTRIES', '<span class="coming"><strong>NOTE:</strong></span> A maximum of %s address book entries allowed.');
define('TEXT_INFO_ADDRESS_BOOK_COUNT', ' | 1 of  ');
?>