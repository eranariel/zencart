<?php
/**
 * Module Name:  Group Pricing Per Item
 */
define('GROUP_PRICE_PER_ITEM_TEXT', 'Per Item');
define('GROUP_PRICE_PER_ITEM_ADMIN_NOTE', "'" . GROUP_PRICE_PER_ITEM1 . "', '" . GROUP_PRICE_PER_ITEM2 . "', '" . GROUP_PRICE_PER_ITEM3 . "' and '" . GROUP_PRICE_PER_ITEM4 . "' are reserved for per-product pricing.");
?>