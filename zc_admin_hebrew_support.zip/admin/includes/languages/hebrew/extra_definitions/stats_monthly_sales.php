<?php
/*
 $Id: stats_monthly_sales.php, v 1.4 2011/11/24  $																    
                                                     
  By SkipWater <skip@ccssinc.net> 11.24.2011
                                                      
  Powered by Zen-Cart (www.zen-cart.com)              
  Portions Copyright (c) 2006 The Zen Cart Team       
                                                      
  Released under the GNU General Public License       
  available at www.zen-cart.com/license/2_0.txt       
  or see "license.txt" in the downloaded zip          

  DESCRIPTION: Monthly Sales Report	

*/

define('FILENAME_STATS_MONTHLY_SALES', 'stats_monthly_sales');
define('BOX_STATS_SALES_TOTALS', 'Monthly Sales');

?>