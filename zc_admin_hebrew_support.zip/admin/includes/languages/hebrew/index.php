<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
//  $Id: index.php 2539 2005-12-11 05:17:05Z ajeh $
//

define('HEADING_TITLE', 'Choose an action..');

define('BOX_TITLE_ORDERS', 'הזמנות');
define('BOX_TITLE_STATISTICS', 'סטטיסטיקה');

define('BOX_ENTRY_SUPPORT_SITE', 'Support Site');
define('BOX_ENTRY_SUPPORT_FORUMS', 'Support Forums');
define('BOX_ENTRY_MAILING_LISTS', 'Mailing Lists');
define('BOX_ENTRY_BUG_REPORTS', 'Bug Reports');

define('BOX_ENTRY_FAQ', 'FAQ');
define('BOX_ENTRY_LIVE_DISCUSSIONS', 'Live Discussions');
define('BOX_ENTRY_CVS_REPOSITORY', 'CVS Repository');
define('BOX_ENTRY_INFORMATION_PORTAL', 'Information Portal');

define('BOX_CONNECTION_PROTECTED', 'You are protected by a %s secure SSL connection.');
define('BOX_CONNECTION_UNPROTECTED', 'You are <font color="#ff0000">not</font> protected by a secure SSL connection.');
define('BOX_CONNECTION_UNKNOWN', 'unknown');

define('CATALOG_CONTENTS', 'Contents');
define('TOOLS_BACKUP', 'Backup');
define('TOOLS_BANNERS', 'Banners');
define('TOOLS_FILES', 'Files');

// statistics
  define('REPORTS_PRODUCTS', 'מוצרים:');
  define('REPORTS_ORDERS', 'הזמנות:');

define('BOX_ENTRY_CUSTOMERS', 'לקוחות:');
define('BOX_ENTRY_NEWSLETTERS', 'מינוי לתפוצת עיתון החנות:');

define('BOX_ENTRY_PRODUCTS', 'סה"כ מוצרים בחנות:');
define('BOX_ENTRY_PRODUCTS_OFF', 'מוצרים שאינם פעילים:');
define('BOX_ENTRY_REVIEWS', 'חוות דעת:');
define('BOX_ENTRY_REVIEWS_PENDING', 'חוות דעת הממתינות לאישור:');

  define('BOX_ENTRY_NEW_CUSTOMERS', 'לקוחות חדשים:');
  define('BOX_ENTRY_NEW_ORDERS', 'הזמנות חדשות:');

  define('BOX_ENTRY_SPECIALS_EXPIRED','פקיעת תוקף מבצעים: ');
define('BOX_ENTRY_FEATURED_EXPIRED','פקיעת תוקף "מובחרים" ');
define('BOX_ENTRY_SALEMAKER_EXPIRED','פקיעת מבצעי מכירות');

  define('BOX_ENTRY_SPECIALS_ACTIVE','מבצעים מיוחדים פעילים:');
  define('BOX_ENTRY_FEATURED_ACTIVE','מוצרים "מובחרים" פעילים:');
  define('BOX_ENTRY_SALEMAKER_ACTIVE','Sales Active:');

define('LAST_10_DAYS', 'היסטוריה ספירת הפעלות%s ימים אחרונים');
define('SESSION', 'הפעלות');
define('TOTAL', 'סה"כ');
?>