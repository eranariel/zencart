<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// $Id: password_forgotten.php 4820 2006-10-23 07:19:46Z drbyte $
//

define('HEADING_TITLE', 'שלח קוד סודי');
define('TEXT_BUTTON_REQUEST_RESET', 'שליחת הבקשה'); 
define('TEXT_BUTTON_CANCEL', 'ביטול וחזרה למסך כניסה'); 

define('TEXT_ADMIN_EMAIL', 'מייל מנהל המערכת: ');

define('ERROR_WRONG_EMAIL', '<p>הקלדת כתובת מייל שגוייה.</p>');
define('ERROR_WRONG_EMAIL_NULL', '<p>לך מכאן ראש קרוב :-P</p>');
define('SUCCESS_PASSWORD_SENT', '<p>קוד סודי מעודכן נשלח לך לכתובת המייל.</p>');

define('TEXT_EMAIL_SUBJECT', 'השינוי שביקשת');
define('TEXT_EMAIL_FROM', EMAIL_FROM);
define('TEXT_EMAIL_MESSAGE', 'קוד סוי חדש התבקש על ידי ' . $_SERVER['REMOTE_ADDR']  . '.' . "\n\n" . 'הקוד החדש ל- \'' . STORE_NAME . '\' is:' . "\n\n" . '   %s' . "\n\nלאחר שהתחברת באמצעות הסיסמה החדשה, אתה יכול לשנות אותו על ידי לחיצה על 'Tools->Admin Settings' area.");

?>