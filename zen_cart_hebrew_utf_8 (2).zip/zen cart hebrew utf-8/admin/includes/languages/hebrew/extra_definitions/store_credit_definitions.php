<?
/* Start Store Credit Order Total Module */
define('TEXT_SC_NAME', 'Store Credit');
define('TEXT_SC_NAMES', 'Store Credits');
define('BOX_CUSTOMERS_CREDIT', 'Store Credit');
define('TEXT_REMIND_PENDING_CUSTOMERS_EMAIL_TEXT', 'Hey There-' . "\n\n" . 'Just a quick reminder to let you know that you\'ve got an unused ' . STORE_NAME . ' ' . strtolower(TEXT_SC_NAME) . '!' . "\n\n" . 'Credit Amount: %s' . "\n\n" . 'To redeem your credit, please create an account here: %s' . "\n\n" . 'Your ' . strtolower(TEXT_SC_NAME) . ' may be applied at checkout.' . "\n\n" . 'Thanks!' . "\n\n" . '-Team ' . STORE_NAME . "\n");
//eof