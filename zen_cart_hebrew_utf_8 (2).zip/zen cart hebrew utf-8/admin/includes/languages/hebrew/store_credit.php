<?php
define('HEADING_TITLE', 'Store Credit');

define('TABLE_HEADING_ID', 'ID#');
define('TABLE_HEADING_FIRSTNAME', 'First Name');
define('TABLE_HEADING_LASTNAME', 'Last Name');
define('TABLE_HEADING_BALANCE', 'Credit Balance');
define('TABLE_HEADING_PENDING', 'Pending Rewards');
define('TABLE_HEADING_EMAIL', 'Email Address');

define('HEADING_CUSTOMERS_REFERRED', 'Customers Referred');

define('TYPE_BELOW', 'Type below');
define('PLEASE_SELECT', 'Select One');

define('ENTRY_NONE', 'None');
define('ENTRY_BALANCE', 'Store Credit Balance');

define('TABLE_HEADING_COMPANY','Company');
//eof