<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: hebrew.php 400432 2013-10-26 15:00:35Z eranariel $
 * @Localization: eran (aran) ariel http://www.eranariel.com
 */

// FOLLOWING WERE moved to meta_tags.php
//define('TITLE', 'Zen Cart!');
//define('SITE_TAGLINE', 'The Art of E-commerce');
//define('CUSTOM_KEYWORDS', 'ecommerce, open source, shop, online shopping');
// END: moved to meta_tags.php

  define('FOOTER_TEXT_BODY', 'Copyright &copy; ' . date('Y') . ' <a href="' . zen_href_link(FILENAME_DEFAULT) . '" target="_blank">' . STORE_NAME . '</a>. Powered by <a href="http://www.zen-cart.com" target="_blank">Zen Cart</a>');

// look in your $PATH_LOCALE/locale directory for available locales..
// on RedHat try 'en_US'
// on FreeBSD try 'en_US.ISO_8859-1'
// on Windows try 'en', or 'English'
  @setlocale(LC_TIME, 'en_US.ISO_8859-1');
  define('DATE_FORMAT_SHORT', '%d/%m/%Y');  // this is used for strftime()
  define('DATE_FORMAT_LONG', '%A %d %B, %Y'); // this is used for strftime()
  define('DATE_FORMAT', 'd/m/Y'); // this is used for date()
  define('DATE_TIME_FORMAT', DATE_FORMAT_SHORT . ' %H:%M:%S');

////
// Return date in raw format
// $date should be in format mm/dd/yyyy
// raw date is in format YYYYMMDD, or DDMMYYYY
  if (!function_exists('zen_date_raw')) {
    function zen_date_raw($date, $reverse = false) {
      if ($reverse) {
        return substr($date, 3, 2) . substr($date, 0, 2) . substr($date, 6, 4);
      } else {
        return substr($date, 6, 4) . substr($date, 0, 2) . substr($date, 3, 2);
      }
    }
  }

// if USE_DEFAULT_LANGUAGE_CURRENCY is true, use the following currency, instead of the applications default currency (used when changing language)
  define('LANGUAGE_CURRENCY', 'ILS');

// Global entries for the <html> tag
  define('HTML_PARAMS','dir="rtl" lang="he"');

// charset for web pages and emails
  define('CHARSET', 'UTF-8');

// footer text in includes/footer.php
  define('FOOTER_TEXT_REQUESTS_SINCE', 'כניסות מ');

// Define the name of your Gift Certificate as Gift Voucher, Gift Certificate, Zen Cart Dollars, etc. here for use through out the shop
  define('TEXT_GV_NAME','תלוש מתנה');
  define('TEXT_GV_NAMES','תלושי מתנה');

// used for redeem code, redemption code, or redemption id
  define('TEXT_GV_REDEEM','קוד פדייה');

// used for redeem code sidebox
  define('BOX_HEADING_GV_REDEEM', TEXT_GV_NAME);
  define('BOX_GV_REDEEM_INFO', 'קוד פדייה: ');

// text for gender
  define('MALE', 'אדון');
  define('FEMALE', 'גברת');
  define('MALE_ADDRESS', 'אדוני');
  define('FEMALE_ADDRESS', 'גברתי');

// text for date of birth example
  define('DOB_FORMAT_STRING', 'dd/mm/yyyy');

//text for sidebox heading links
  define('BOX_HEADING_LINKS', '&nbsp;&nbsp;[עוד]');

// categories box text in sideboxes/categories.php
  define('BOX_HEADING_CATEGORIES', 'קטגוריות');

// manufacturers box text in sideboxes/manufacturers.php
  define('BOX_HEADING_MANUFACTURERS', 'יצרנים');

// whats_new box text in sideboxes/whats_new.php
  define('BOX_HEADING_WHATS_NEW', 'מוצרים חדשים');
  define('CATEGORIES_BOX_HEADING_WHATS_NEW', 'מוצרים חדשים ...');

  define('BOX_HEADING_FEATURED_PRODUCTS', 'מומלצים');
  define('CATEGORIES_BOX_HEADING_FEATURED_PRODUCTS', 'מוצרים מומלצים ...');
  define('TEXT_NO_FEATURED_PRODUCTS', 'מוצרים מומלצים נוספים יתווספו בהמשך.');

  define('TEXT_NO_ALL_PRODUCTS', 'מוצרים נוספים יתווספו בהמשך.');
  define('CATEGORIES_BOX_HEADING_PRODUCTS_ALL', 'כל המוצרים ...');

// quick_find box text in sideboxes/quick_find.php
  define('BOX_HEADING_SEARCH', 'חפש');
  define('BOX_SEARCH_ADVANCED_SEARCH', 'חיפוש מתקדם');

// specials box text in sideboxes/specials.php
  define('BOX_HEADING_SPECIALS', 'מבצעים מיוחדים');
  define('CATEGORIES_BOX_HEADING_SPECIALS','מבצעים מיוחדים ...');

// reviews box text in sideboxes/reviews.php
  define('BOX_HEADING_REVIEWS', 'ביקורות');
  define('BOX_REVIEWS_WRITE_REVIEW', 'כתוב ביקורת למוצר זה.');
  define('BOX_REVIEWS_NO_REVIEWS', 'כרגע אין ביקורות למוצר זה.');
  define('BOX_REVIEWS_TEXT_OF_5_STARS', '%s מתוך 5 כוכבים!');

// shopping_cart box text in sideboxes/shopping_cart.php
  define('BOX_HEADING_SHOPPING_CART', 'עגלת קניות');
  define('BOX_SHOPPING_CART_EMPTY', '0 מוצרים.');
  define('BOX_SHOPPING_CART_DIVIDER', '-&nbsp;');

// order_history box text in sideboxes/order_history.php
  define('BOX_HEADING_CUSTOMER_ORDERS', 'קניות אחרונות');

// best_sellers box text in sideboxes/best_sellers.php
  define('BOX_HEADING_BESTSELLERS', 'רבי מכר');
  define('BOX_HEADING_BESTSELLERS_IN', 'רבי מכר ב<br /> ');

// notifications box text in sideboxes/products_notifications.php
define('BOX_HEADING_NOTIFICATIONS', 'הודעות');
define('BOX_NOTIFICATIONS_NOTIFY', 'הודיעו לי על עדכונים של <strong>%s</strong>');
define('BOX_NOTIFICATIONS_NOTIFY_REMOVE', 'אל תודיעו לי על עדכונים של <strong>%s</strong>');

// manufacturer box text
define('BOX_HEADING_MANUFACTURER_INFO', 'מידע על היצרן');
define('BOX_MANUFACTURER_INFO_HOMEPAGE', '%s דף הבית');
define('BOX_MANUFACTURER_INFO_OTHER_PRODUCTS', 'מוצרים אחרים');

// languages box text in sideboxes/languages.php
define('BOX_HEADING_LANGUAGES', 'שפות');

// currencies box text in sideboxes/currencies.php
define('BOX_HEADING_CURRENCIES', 'מטבע');

// information box text in sideboxes/information.php
define('BOX_HEADING_INFORMATION', 'מידע');
define('BOX_INFORMATION_PRIVACY', 'פרטיות');
define('BOX_INFORMATION_CONDITIONS', 'תנאי שימוש');
define('BOX_INFORMATION_SHIPPING', 'משלוחים');
define('BOX_INFORMATION_CONTACT', 'צור קשר');
define('BOX_BBINDEX', 'פורןם');
define('BOX_INFORMATION_UNSUBSCRIBE', 'הסר מרשימת תפוצה');

  define('BOX_INFORMATION_SITE_MAP', 'מפת האתר');
// information box text in sideboxes/more_information.php
  define('BOX_HEADING_MORE_INFORMATION', 'עוד מידע');
  define('BOX_INFORMATION_PAGE_2', 'דף 2');
  define('BOX_INFORMATION_PAGE_3', 'דף 3');
  define('BOX_INFORMATION_PAGE_4', 'דף 4');

// tell a friend box text in sideboxes/tell_a_friend.php
define('BOX_HEADING_TELL_A_FRIEND', 'ספר לחבר');
define('BOX_TELL_A_FRIEND_TEXT', 'ספר למישהו על מוצר זה');

// wishlist box text in includes/boxes/wishlist.php
define('BOX_HEADING_CUSTOMER_WISHLIST', 'רשימת המשאלות');
define('BOX_WISHLIST_EMPTY', 'אין מוצרים ברשימת המשאלות');
define('IMAGE_BUTTON_ADD_WISHLIST', 'הוסף לרשימת המשאלות');
define('TEXT_WISHLIST_COUNT', 'יש לך %s מוצרים ברשימת המשאלות');
define('TEXT_DISPLAY_NUMBER_OF_WISHLIST', 'מוצגים <strong>%d</strong> עד <strong>%d</strong> מ <strong>%d</strong> מוצרים ברשימת המשאלות');

//New billing address text
define('SET_AS_PRIMARY' , 'קבע ככתובת ראשית');
define('NEW_ADDRESS_TITLE', 'כתובת לחיוב');

// javascript messages
define('JS_ERROR', 'ארעה שגיאה, נא תקן את הדברים הבאים:nn');

  define('JS_REVIEW_TEXT', '* אנא הוסף עוד מספר מילים לביקורת שלך. אורך הביקורת צריך להיות באורך: ' . REVIEW_TEXT_MIN_LENGTH . ' characters.');
  define('JS_REVIEW_RATING', '* אנא בחר דירוג למוצר זה.');

define('JS_ERROR_NO_PAYMENT_MODULE_SELECTED', '* אנא בחר שיטת חיוב');

define('JS_ERROR_SUBMITTED', 'הפרטים כבר נשלחו, לחץ OK והמתן לאישור.');

define('ERROR_NO_PAYMENT_MODULE_SELECTED', 'אנא בחר שיטת חיוב.');
define('ERROR_CONDITIONS_NOT_ACCEPTED', 'אנא אשר שקראת והסכמת לתנאי שימוש באתר.');
define('ERROR_PRIVACY_STATEMENT_NOT_ACCEPTED', 'אנא אשר שקראת והסכמת לתנאי פרטיות');

define('CATEGORY_COMPANY', 'פרטי חברה');
define('CATEGORY_PERSONAL', 'פרטים אישיים');
define('CATEGORY_ADDRESS', 'כתובת');
define('CATEGORY_CONTACT', 'איך ניתן ליצור איתך קשר?');
define('CATEGORY_OPTIONS', 'אפשרויות');
define('CATEGORY_PASSWORD', 'סיסמה');
define('CATEGORY_LOGIN', 'התחבר');
define('PULL_DOWN_DEFAULT', 'נא לבחור מדינה');
  define('PLEASE_SELECT', 'אנא בחר...');
  define('TYPE_BELOW', 'הכנס את בחירתך...');

define('ENTRY_COMPANY', 'שם חברה');
 define('ENTRY_COMPANY_ERROR', 'אנא הכנס את שם החברה.');
define('ENTRY_COMPANY_TEXT', '');
define('ENTRY_GENDER', 'בחר מינך:');
define('ENTRY_GENDER_ERROR', 'בחר צורת פניה מתאימה:');
define('ENTRY_GENDER_TEXT', '*');
define('ENTRY_FIRST_NAME', 'שם פרטי:');
define('ENTRY_FIRST_NAME_ERROR', 'שם פרטי חייב להיות לפחות ' . ENTRY_FIRST_NAME_MIN_LENGTH . ' אותיות.');
define('ENTRY_FIRST_NAME_TEXT', '*');
define('ENTRY_LAST_NAME', 'שם משפחה:');
define('ENTRY_LAST_NAME_ERROR', 'שם משפחה חייב להיות לפחות ' . ENTRY_LAST_NAME_MIN_LENGTH . ' אותיות.');
define('ENTRY_LAST_NAME_TEXT', '*');
define('ENTRY_DATE_OF_BIRTH', 'תאריך לידה:');
define('ENTRY_DATE_OF_BIRTH_ERROR', 'תאריך לידה חייב להיות בפורמט של: 21/05/1972');
define('ENTRY_DATE_OF_BIRTH_TEXT', '(21/05/1972)');
define('ENTRY_EMAIL_ADDRESS', 'כתובת דואר אלקטרוני:');
define('ENTRY_EMAIL_ADDRESS_ERROR', 'דואר אלקטרוני חייב להיות לפחות ' . ENTRY_EMAIL_ADDRESS_MIN_LENGTH . ' תווים.');
define('ENTRY_EMAIL_ADDRESS_CHECK_ERROR', 'כתובת הדואר האלקטרוני לא תקינה, נא בצע את התיקון הנדרש');
define('ENTRY_EMAIL_ADDRESS_ERROR_EXISTS', 'כתובת הדואר כבר רשומה אצלנו, אנא הכנס בעזרתה או הרשם עם כתובת אחרת');
define('ENTRY_EMAIL_ADDRESS_TEXT', '*');
define('ENTRY_NICK', 'כינוי בפורום:');
define('ENTRY_NICK_TEXT', '*'); // note to display beside nickname input field
define('ENTRY_NICK_DUPLICATE_ERROR', 'כינוי כזה כבר קיים');
define('ENTRY_NICK_LENGTH_ERROR', 'תווים' . ENTRY_NICK_MIN_LENGTH . 'הכינוי צריך להיות מורכב מינימום מ');
define('ENTRY_STREET_ADDRESS', 'כתובת:');
define('ENTRY_STREET_ADDRESS_ERROR', 'כתובת חייבת להיות לפחות ' . ENTRY_STREET_ADDRESS_MIN_LENGTH . ' אותיות.');
define('ENTRY_STREET_ADDRESS_TEXT', '*');
define('ENTRY_SUBURB', 'כתובת (שורה נוספת):');
define('ENTRY_SUBURB_ERROR', '');
define('ENTRY_SUBURB_TEXT', '');
define('ENTRY_POST_CODE', 'מיקוד:');
define('ENTRY_POST_CODE_ERROR', 'המיקוד חייב להכיל לפחות ' . ENTRY_POSTCODE_MIN_LENGTH . ' תווים.');
define('ENTRY_POST_CODE_TEXT', '*');
define('ENTRY_CITY', 'עיר:');
define('ENTRY_CUSTOMERS_REFERRAL', 'קוד הממליץ:');

 define('ENTRY_CITY_ERROR', 'שם העיר חייב להיות לפחות' . ENTRY_CITY_MIN_LENGTH . ' אותיות.');
define('ENTRY_CITY_TEXT', '*');
define('ENTRY_STATE', 'איזור:');
define('ENTRY_STATE_ERROR', 'שם האזור חייב להיות לפחות' . ENTRY_STATE_MIN_LENGTH . ' אותיות.');
define('ENTRY_STATE_ERROR_SELECT', 'תבחר בבקשה אזור מרשימת האזורים');
define('ENTRY_STATE_TEXT', '*');
  define('JS_STATE_SELECT', '-- אנא בחר/י --');
define('ENTRY_COUNTRY', 'מדינה:');
define('ENTRY_COUNTRY_ERROR', 'תבחר בבקשה אזור מרשימת הארצות');
define('ENTRY_COUNTRY_TEXT', '*');
define('ENTRY_TELEPHONE_NUMBER', 'מספר טלפון:');
define('ENTRY_TELEPHONE_NUMBER_ERROR', 'מס טלפון  חייב להיות לפחות' . ENTRY_TELEPHONE_MIN_LENGTH . 'ספרות');
define('ENTRY_TELEPHONE_NUMBER_TEXT', '*');
define('ENTRY_FAX_NUMBER', 'מספר פקס:');
define('ENTRY_FAX_NUMBER_ERROR', '');
define('ENTRY_FAX_NUMBER_TEXT', '');
define('ENTRY_NEWSLETTER', 'כן, אני רוצה לקבל מסרים אלקטרוניים מעת לעת');
define('ENTRY_NEWSLETTER_TEXT', '');
define('ENTRY_NEWSLETTER_YES', 'הרשם');
define('ENTRY_NEWSLETTER_NO', 'אל תרשם');
define('ENTRY_NEWSLETTER_ERROR', '');
define('ENTRY_PASSWORD', 'סיסמה:');
define('ENTRY_PASSWORD_ERROR', 'סיסמה חייבת להיות לפחות' . ENTRY_PASSWORD_MIN_LENGTH . 'תווים');
define('ENTRY_PASSWORD_ERROR_NOT_MATCHING', 'סיסמה ואישור סיסמה חייבים להיות זהים');
define('ENTRY_PASSWORD_TEXT', '* (לפחות ' . ENTRY_PASSWORD_MIN_LENGTH . ' תווים)');
define('ENTRY_PASSWORD_CONFIRMATION', 'אשר סיסמה:');
define('ENTRY_PASSWORD_CONFIRMATION_TEXT', '*');
define('ENTRY_PASSWORD_CURRENT', 'הסיסמה הנוכחית:');
define('ENTRY_PASSWORD_CURRENT_TEXT', '*');
define('ENTRY_PASSWORD_CURRENT_ERROR', 'סיסמה חייבת להיות לפחות' . ENTRY_PASSWORD_MIN_LENGTH . 'תווים');
define('ENTRY_PASSWORD_NEW', 'סיסמה חדשה:');
define('ENTRY_PASSWORD_NEW_TEXT', '*');
define('ENTRY_PASSWORD_NEW_ERROR', 'סיסמה חייבת להיות לפחות' . ENTRY_PASSWORD_MIN_LENGTH . 'תווים');
define('ENTRY_PASSWORD_NEW_ERROR_NOT_MATCHING', 'שתי הסיסמאות חייבות להיות זהות.');
define('PASSWORD_HIDDEN', '--מוסתר--');

  define('FORM_REQUIRED_INFORMATION', '* חובה למלא');
  define('ENTRY_REQUIRED_SYMBOL', '*');

  // constants for use in zen_prev_next_display function
define('TEXT_RESULT_PAGE', '');
define('TEXT_DISPLAY_NUMBER_OF_PRODUCTS', 'מציג <strong>%d</strong> עד <strong>%d</strong> (מתוך <strong>%d</strong> מוצרים)');
define('TEXT_DISPLAY_NUMBER_OF_ORDERS', 'מציג <strong>%d</strong> עד <strong>%d</strong> (מתוך <strong>%d</strong> הזמנות)');
define('TEXT_DISPLAY_NUMBER_OF_REVIEWS', 'מציג <strong>%d</strong> עד <strong>%d</strong> (מתוך <strong>%d</strong> סקירות)');
define('TEXT_DISPLAY_NUMBER_OF_PRODUCTS_NEW', 'מציג <strong>%d</strong> עד <strong>%d</strong> (מתוך <strong>%d</strong> מוצרים חדשים)');
define('TEXT_DISPLAY_NUMBER_OF_SPECIALS', 'מציג <strong>%d</strong> עד <strong>%d</strong> (מתוך <strong>%d</strong> מבצעים)');
define('TEXT_DISPLAY_NUMBER_OF_PRODUCTS_FEATURED_PRODUCTS', 'מציג <strong>%d</strong> עד <strong>%d</strong> (מתוך <strong>%d</strong> מומלצים)');
define('TEXT_DISPLAY_NUMBER_OF_PRODUCTS_ALL', 'מציג <strong>%d</strong> עד <strong>%d</strong> (מתוך <strong>%d</strong> מוצרים)');

define('PREVNEXT_TITLE_FIRST_PAGE', 'עמוד ראשון');
define('PREVNEXT_TITLE_PREVIOUS_PAGE', 'עמוד קודם');
define('PREVNEXT_TITLE_NEXT_PAGE', 'עמוד הבא');
define('PREVNEXT_TITLE_LAST_PAGE', 'עמוד אחרון');
define('PREVNEXT_TITLE_PAGE_NO', 'עמוד %d');
define('PREVNEXT_TITLE_PREV_SET_OF_NO_PAGE', '%d דפים קודמים');
define('PREVNEXT_TITLE_NEXT_SET_OF_NO_PAGE', '%d דפים הבאים');
define('PREVNEXT_BUTTON_FIRST', '<<ראשון');
define('PREVNEXT_BUTTON_PREV', '[<< קודם]');
define('PREVNEXT_BUTTON_NEXT', '[הבא >>]');
define('PREVNEXT_BUTTON_LAST', 'אחרון>>');

define('TEXT_BASE_PRICE','מתחיל ב:');

define('TEXT_CLICK_TO_ENLARGE', 'תמונה מוגדלת');

define('TEXT_SORT_PRODUCTS', 'סדר ');
define('TEXT_DESCENDINGLY', 'סדר יורד');
define('TEXT_ASCENDINGLY', 'סדר עולה');
define('TEXT_BY', ' לפי ');

define('TEXT_REVIEW_BY', 'של %s');
define('TEXT_REVIEW_WORD_COUNT', '%s מילים');
define('TEXT_REVIEW_RATING', 'דירוג: %s [%s]');
define('TEXT_REVIEW_DATE_ADDED', 'תאריך הוספה: %s');
define('TEXT_NO_REVIEWS', 'אין סקירות.');

  define('TEXT_NO_NEW_PRODUCTS', 'More new products will be added soon. Please check back later.');

  define('TEXT_UNKNOWN_TAX_RATE', 'Sales Tax');

  define('TEXT_REQUIRED', '<span class="errorText">Required</span>');

  define('WARNING_INSTALL_DIRECTORY_EXISTS', 'Warning: Installation directory exists at: %s. Please remove this directory for security reasons.');
  define('WARNING_CONFIG_FILE_WRITEABLE', 'Warning: I am able to write to the configuration file: %s. This is a potential security risk - please set the right user permissions on this file (read-only, CHMOD 644 or 444 are typical). You may need to use your webhost control panel/file-manager to change the permissions effectively. Contact your webhost for assistance. <a href="http://tutorials.zen-cart.com/index.php?article=90" target="_blank">See this FAQ</a>');
  define('ERROR_FILE_NOT_REMOVEABLE', 'Error: Could not remove the file specified. You may have to use FTP to remove the file, due to a server-permissions configuration limitation.');
  define('WARNING_SESSION_DIRECTORY_NON_EXISTENT', 'Warning: The sessions directory does not exist: ' . zen_session_save_path() . '. Sessions will not work until this directory is created.');
  define('WARNING_SESSION_DIRECTORY_NOT_WRITEABLE', 'Warning: I am not able to write to the sessions directory: ' . zen_session_save_path() . '. Sessions will not work until the right user permissions are set.');
  define('WARNING_SESSION_AUTO_START', 'Warning: session.auto_start is enabled - please disable this PHP feature in php.ini and restart the web server.');
  define('WARNING_DOWNLOAD_DIRECTORY_NON_EXISTENT', 'Warning: The downloadable products directory does not exist: ' . DIR_FS_DOWNLOAD . '. Downloadable products will not work until this directory is valid.');
  define('WARNING_SQL_CACHE_DIRECTORY_NON_EXISTENT', 'Warning: The SQL cache directory does not exist: ' . DIR_FS_SQL_CACHE . '. SQL caching will not work until this directory is created.');
  define('WARNING_SQL_CACHE_DIRECTORY_NOT_WRITEABLE', 'Warning: I am not able to write to the SQL cache directory: ' . DIR_FS_SQL_CACHE . '. SQL caching will not work until the right user permissions are set.');
  define('WARNING_DATABASE_VERSION_OUT_OF_DATE', 'Your database appears to need patching to a higher level. See Admin->Tools->Server Information to review patch levels.');
  define('WARNING_COULD_NOT_LOCATE_LANG_FILE', 'WARNING: Could not locate language file: ');

define('TEXT_CCVAL_ERROR_INVALID_DATE', 'תוקף כרטיס אשראי שגוי. אנא בדקו את התאריך.');
define('TEXT_CCVAL_ERROR_INVALID_NUMBER', 'מספר כרטיס אשראי שגוי. אנא נסו שוב להכניס מספר נכון.');
define('TEXT_CCVAL_ERROR_UNKNOWN_CARD', 'ארבע הספרות הראשונות של הכרטיס הן: %s. אם המספר הזה נכון, אנחנו לא מקבלים כרטיס אשראי מסוג כזה. אחרת, אנא הכנס את המספר שוב.');

define('BOX_INFORMATION_DISCOUNT_COUPONS', 'קופוני הנחה');
define('BOX_INFORMATION_GV', TEXT_GV_NAME . ' שאלות נפוצות');
define('VOUCHER_BALANCE', TEXT_GV_NAME . ' אשראי ');
define('BOX_HEADING_GIFT_VOUCHER', TEXT_GV_NAME . ' חשבון');
define('GV_FAQ', TEXT_GV_NAME . ' שאלות נפוצות');
define('ERROR_REDEEMED_AMOUNT', 'איחולי, פדית ');
define('ERROR_NO_REDEEM_CODE', 'לא הכנסתה את ה' . TEXT_GV_REDEEM . '.');
define('ERROR_NO_INVALID_REDEEM_GV', 'לא קביל' . TEXT_GV_NAME . ' ' . TEXT_GV_REDEEM);
define('TABLE_HEADING_CREDIT', 'קרדיט זמין');
define('GV_HAS_VOUCHERA', 'יש לך קרדיט בחשבון' . TEXT_GV_NAME . '. אם אתה רוצה<br />
                         אתה יכול לשלוח קרדיט זה על ידי <a class="pageResults" href="');

define('GV_HAS_VOUCHERB', '"><strong>דואר אלקטרוני</strong></a> למישהו');
define('ENTRY_AMOUNT_CHECK_ERROR', 'אין לך מספיק קרדיט בשביל לשלוח כמות כזו.');
define('BOX_SEND_TO_FRIEND', 'שלח ' . TEXT_GV_NAME . ' ');

define('VOUCHER_REDEEMED',  TEXT_GV_NAME . ' נפדה');
define('CART_COUPON', 'קופון :');
define('CART_COUPON_INFO', 'לפרטים');
  define('TEXT_SEND_OR_SPEND','יש לך קרדיט זמין בחשבון ' . TEXT_GV_NAME . '. אתה יכול לקנות משהו או לשלוח את זה למישהו אחר. בשביל לשלוח, לחץ על הכפתור למטה.');
  define('TEXT_BALANCE_IS', 'מצב חשבון ה-' . TEXT_GV_NAME . ' שלך הוא: ');
  define('TEXT_AVAILABLE_BALANCE', 'חשבון ה-' . TEXT_GV_NAME . ' שלך');

// payment method is GV/Discount
  define('PAYMENT_METHOD_GV', 'תלושי מתנה וקופונים');
  define('PAYMENT_MODULE_GV', 'תלושי מתנה וקופונים');
define('TABLE_HEADING_CREDIT_PAYMENT', 'קרדיטים זמינים');

define('TEXT_INVALID_REDEEM_COUPON', 'קוד קופון שגוי');
  define('TEXT_INVALID_REDEEM_COUPON_MINIMUM', 'אתה חייב להוציא יותר מ%s בשביל לפדות את קופון זה');
define('TEXT_INVALID_STARTDATE_COUPON', 'קופון זה עדיין לא בתוקף');
  define('TEXT_INVALID_FINISHDATE_COUPON', 'תוקף קופון זה עבר');
define('EXT_INVALID_USES_COUPON', 'קופון זה יכול להיות בשימוש רק  ');
define('TIMES', ' פעמים.');
define('TIME', ' פעמים.');
define('TEXT_INVALID_USES_USER_COUPON', 'השתמשת בקופון: %s כמספר הפעמים שהורשה עבור לקוח. ');
define('REDEEMED_COUPON', 'ערך הקופון ');
define('REDEEMED_MIN_ORDER', 'בהזמנות בסכום שעובר על ');
define('REDEEMED_RESTRICTIONS', ' [הגבלת קטגוריה/מוצר פעילה]');
define('TEXT_ERROR', 'שגיאה');
  define('TEXT_INVALID_COUPON_PRODUCT', 'קופון זה לא בתוקף עבור אף אחד מהמוצרים הנמצאים בעגלה כרגע.');
  define('TEXT_VALID_COUPON', 'איחולי! פדית את הקופון!');
  define('TEXT_REMOVE_REDEEM_COUPON_ZONE', 'הקופון שהכנסת לא תקף לכתובת אותה הכנסת.');

// more info in place of buy now
  define('MORE_INFO_TEXT','... עוד פרטים');

// IP Address
  define('TEXT_YOUR_IP_ADDRESS','כתובת הIP שלך היא: ');

//Generic Address Heading
  define('HEADING_ADDRESS_INFORMATION','כתובת ומידע אישא');

// cart contents
  define('PRODUCTS_ORDER_QTY_TEXT_IN_CART','כמות בסל: ');
  define('PRODUCTS_ORDER_QTY_TEXT','הוסף לסל: ');

// success messages for added to cart when display cart is off
// set to blank for no messages
// for all pages except where multiple add to cart is used:
  define('SUCCESS_ADDED_TO_CART_PRODUCT', 'מוצר נוסף לסל בהצלחה ...');
// only for where multiple add to cart is used:
  define('SUCCESS_ADDED_TO_CART_PRODUCTS', 'המוצרים נוספו לעגלה בהצלחה ...');

  define('TEXT_PRODUCT_WEIGHT_UNIT','גרמים');

// Shipping
  define('TEXT_SHIPPING_WEIGHT','גרמים');
  define('TEXT_SHIPPING_BOXES', 'אריזות');

// Discount Savings
  define('PRODUCT_PRICE_DISCOUNT_PREFIX','תחסוך:&nbsp;');
  define('PRODUCT_PRICE_DISCOUNT_PERCENTAGE','%');
  define('PRODUCT_PRICE_DISCOUNT_AMOUNT','&nbsp;');

// Sale Maker Sale Price
  define('PRODUCT_PRICE_SALE','מבצע: ');

//universal symbols
  define('TEXT_NUMBER_SYMBOL', '# ');

// banner_box
  define('BOX_HEADING_BANNER_BOX','מממנים');
  define('TEXT_BANNER_BOX','אנא בקר את המממנים שלנו ...');

// banner box 2
  define('BOX_HEADING_BANNER_BOX2','האם ראית ...');
  define('TEXT_BANNER_BOX2','ראה/י זאת עוד היום!');

// banner_box - all
  define('BOX_HEADING_BANNER_BOX_ALL','לאתר הקודם');
  define('TEXT_BANNER_BOX_ALL','אנא בקר את הממנים שלנו ...');

// boxes defines
  define('PULL_DOWN_ALL','אנא בחר/י');
  define('PULL_DOWN_MANUFACTURERS','- נקה -');
// shipping estimator
  define('PULL_DOWN_SHIPPING_ESTIMATOR_SELECT', 'אנא בחר/י');

// general Sort By
  define('TEXT_INFO_SORT_BY','מיין על פי: ');

// close window image popups
  define('TEXT_CLOSE_WINDOW',' - לחץ על התמונה לסגירה');
// close popups
  define('TEXT_CURRENT_CLOSE_WINDOW','[ סגור חלון ]');

// iii 031104 added:  File upload error strings
  define('ERROR_FILETYPE_NOT_ALLOWED', 'שגיאה: סוג קובץ לא מורשה.');
  define('WARNING_NO_FILE_UPLOADED', 'אזהרה: אף קובץ לא הועלה.');
  define('SUCCESS_FILE_SAVED_SUCCESSFULLY', 'הצלחה: קובץ נשמר בהצלחה.');
  define('ERROR_FILE_NOT_SAVED', 'שגיאה: קובץ לא נשמר.');
  define('ERROR_DESTINATION_NOT_WRITEABLE', 'שגיאה: יעד לא ניתן לכתיבה.');
  define('ERROR_DESTINATION_DOES_NOT_EXIST', 'שגיאה: יעד לא קיים.');
  define('ERROR_FILE_TOO_BIG', 'Warning: File was too large to upload!<br />Order can be placed but please contact the site for help with upload');
// End iii added

  define('TEXT_BEFORE_DOWN_FOR_MAINTENANCE', 'לתשומת לבך: אתר זה אמור להיות בתהליך תחזוקה ב: ');
  define('TEXT_ADMIN_DOWN_FOR_MAINTENANCE', 'לתשומת לבך: האתר כרגע בתחזוקה.');

  define('PRODUCTS_PRICE_IS_FREE_TEXT','זה בחינם!');
  define('PRODUCTS_PRICE_IS_CALL_FOR_PRICE_TEXT','צור קשר למחיר');
  define('TEXT_CALL_FOR_PRICE','צור קשר למחיר');

  define('TEXT_INVALID_SELECTION',' בחרת באופציה שגויה: ');
  define('TEXT_ERROR_OPTION_FOR','באופציה בשביל: ');
  define('TEXT_INVALID_USER_INPUT', 'תשומת ליבך נדרשת<br />');

// product_listing
  define('PRODUCTS_QUANTITY_MIN_TEXT_LISTING','מינימום: ');
  define('PRODUCTS_QUANTITY_UNIT_TEXT_LISTING','יחידות: ');
  define('PRODUCTS_QUANTITY_IN_CART_LISTING','בסל:');
  define('PRODUCTS_QUANTITY_ADD_ADDITIONAL_LISTING','הוסף עוד:');

  define('PRODUCTS_QUANTITY_MAX_TEXT_LISTING','מקסימום:');

  define('TEXT_PRODUCTS_MIX_OFF','*Mixed OFF');
  define('TEXT_PRODUCTS_MIX_ON','*Mixed ON');

  define('TEXT_PRODUCTS_MIX_OFF_SHOPPING_CART','<br />*You can not mix the options on this item to meet the minimum quantity requirement.*<br />');
  define('TEXT_PRODUCTS_MIX_ON_SHOPPING_CART','*Mixed Option Values is ON<br />');

  define('ERROR_MAXIMUM_QTY','הכמות אשר הוספה לעגלה שונתה עקב כמות מותרת/אפשרית לרכישה. ראה מוצר זה: ');
  define('ERROR_CORRECTIONS_HEADING','אנא תקן: <br />');
  define('ERROR_QUANTITY_ADJUSTED', 'הכמות אשר הוספה לעגלה שונתה עקב חוסר תמיכה בהוספת כמות בשברים. ראה מוצר זה: ');
  define('ERROR_QUANTITY_CHANGED_FROM', ', שונה מ: ');
  define('ERROR_QUANTITY_CHANGED_TO', ' ל ');
  
// Downloads Controller
  define('DOWNLOADS_CONTROLLER_ON_HOLD_MSG','NOTE: Downloads are not available until payment has been confirmed');
  define('TEXT_FILESIZE_BYTES', ' bytes');
  define('TEXT_FILESIZE_MEGS', ' MB');

// shopping cart errors
  define('ERROR_PRODUCT','המוצר: ');
  define('ERROR_PRODUCT_STATUS_SHOPPING_CART','<br />סליחה, לצערנו המוצר הורד מהמלאי לעת עתה.<br />מוצר זה הורד מסל הקניות שלך.');
  define('ERROR_PRODUCT_QUANTITY_MIN',',  ... שגיאות בכמות מינימום - ');
  define('ERROR_PRODUCT_QUANTITY_UNITS',' ... שגיאות בכמות יחידות - ');
  define('ERROR_PRODUCT_OPTION_SELECTION',' ... ערך אפשרות לא חוקי ');
  define('ERROR_PRODUCT_QUANTITY_ORDERED','הזמנת סה"כ: ');
  define('ERROR_PRODUCT_QUANTITY_MAX',' ... שגיאות בכמות מקסימום - ');
  define('ERROR_PRODUCT_QUANTITY_MIN_SHOPPING_CART',', יש מינימום כמות להזמנה. ');
  define('ERROR_PRODUCT_QUANTITY_UNITS_SHOPPING_CART',' ... שגיאות בכמות יחידות - ');
  define('ERROR_PRODUCT_QUANTITY_MAX_SHOPPING_CART',' ... שגיאות כמות מקסימלית - ');
  define('WARNING_SHOPPING_CART_COMBINED', 'לתשומת ליבך: לנוחיותך, עגלת הקניות הנוכחית שלך אוחדה עם עגלת הקניות מביקורך האחרון. אנא שים לב בעת התשלום');

// error on checkout when $_SESSION['customers_id' does not exist in customers table
  define('ERROR_CUSTOMERS_ID_INVALID', 'מידע לקוח לא יכול להיות מואמת!<br />אנא התחבר או צור מחדש את חשבונך ...');

  define('TABLE_HEADING_FEATURED_PRODUCTS','מוצרים מומלצים');

define('TABLE_HEADING_NEW_PRODUCTS', 'מוצרים חדשים לחודש זה');
define('TABLE_HEADING_UPCOMING_PRODUCTS', 'מוצרים בדרך');
define('TABLE_HEADING_DATE_EXPECTED', 'צפוים להגיעה ב');
define('TABLE_HEADING_SPECIALS_INDEX', 'מבצעים מיוחדים לחודש זה');
  define('CAPTION_UPCOMING_PRODUCTS','מוצרים אלו יהיו במלאי בקרוב');
  define('SUMMARY_TABLE_UPCOMING_PRODUCTS','הטבלה מכילה מוצרים שיגיעו בקרוב למלאי והתאריכים שלהם');

// meta tags special defines
define('META_TAG_PRODUCTS_PRICE_IS_FREE_TEXT','חינם');

// customer login
define('TEXT_SHOWCASE_ONLY','צור קשר');
// set for login for prices
define('TEXT_LOGIN_FOR_PRICE_PRICE','מחיר לא זמין');
define('TEXT_LOGIN_FOR_PRICE_BUTTON_REPLACE','התחבר בשביל מחיר');
// set for show room only
define('TEXT_LOGIN_FOR_PRICE_PRICE_SHOWROOM', ''); // blank for prices or enter your own text
define('TEXT_LOGIN_FOR_PRICE_BUTTON_REPLACE_SHOWROOM','אולם תצוגה בלבד');

// authorization pending
define('TEXT_AUTHORIZATION_PENDING_PRICE', 'מחיר לא זמין');
define('TEXT_AUTHORIZATION_PENDING_BUTTON_REPLACE', 'ממתין לאישור');
  define('TEXT_LOGIN_TO_SHOP_BUTTON_REPLACE','התחבר בשביל להתחיל לקנות');

// text pricing
  define('TEXT_CHARGES_WORD','Calculated Charge:');
  define('TEXT_PER_WORD','<br />Price per word: ');
  define('TEXT_WORDS_FREE',' Word(s) free ');
  define('TEXT_CHARGES_LETTERS','Calculated Charge:');
  define('TEXT_PER_LETTER','<br />Price per letter: ');
  define('TEXT_LETTERS_FREE',' Letter(s) free ');
  define('TEXT_ONETIME_CHARGES','*onetime charges = ');
  define('TEXT_ONETIME_CHARGES_EMAIL',"\t" . '*onetime charges = ');
  define('TEXT_ATTRIBUTES_QTY_PRICES_HELP', 'Option Quantity Discounts');
  define('TABLE_ATTRIBUTES_QTY_PRICE_QTY','כמות');
  define('TABLE_ATTRIBUTES_QTY_PRICE_PRICE','מחיר');
  define('TEXT_ATTRIBUTES_QTY_PRICES_ONETIME_HELP', 'Option Quantity Discounts Onetime Charges');

// textarea attribute input fields
  define('TEXT_MAXIMUM_CHARACTERS_ALLOWED',' maximum characters allowed');
  define('TEXT_REMAINING','remaining');

// Shipping Estimator
  define('CART_SHIPPING_OPTIONS', 'סוגי משלוח:');
  define('CART_SHIPPING_OPTIONS_LOGIN', 'אנא <a href="' . zen_href_link(FILENAME_LOGIN, '', 'SSL') . '"><u>כנסו למערכת</u></a> כדי לראות נתוני משלוח לאזור מגורך');
  define('CART_SHIPPING_METHOD_TEXT','צורת ההובלה: ');
  define('CART_SHIPPING_METHOD_RATES','עלויות:');
  define('CART_SHIPPING_METHOD_TO','שלח ל: ');
  define('CART_SHIPPING_METHOD_TO_NOLOGIN', 'שלח ל: <a href="' . zen_href_link(FILENAME_LOGIN, '', 'SSL') . '"><u>כניסה למערכת</u></a>');
  define('CART_SHIPPING_METHOD_FREE_TEXT','הובלה חינם!');
  define('CART_SHIPPING_METHOD_ALL_DOWNLOADS','- Downloads');
  define('CART_SHIPPING_METHOD_RECALCULATE','חשב שוב');
  define('CART_SHIPPING_METHOD_ZIP_REQUIRED','true');
  define('CART_SHIPPING_METHOD_ADDRESS','כתובת:');
  define('CART_OT','Total Cost Etimate:');
  define('CART_OT_SHOW','true'); // set to false if you don't want order totals
  define('CART_ITEMS','מוצרים בסל הקינות: ');
  define('CART_SELECT','בחר/י:');
  define('ERROR_CART_UPDATE', '<strong>אנא עדכן הזמנתך ...</strong>');
  define('IMAGE_BUTTON_UPDATE_CART', 'עדכון סל קניות');
  define('EMPTY_CART_TEXT_NO_QUOTE', 'אופס! עבר יותר מדי זמן מאז הפעולה האחרונה. אנא רענן את עגלת הקניות בשביל מחירי המשלוח');
  define('CART_SHIPPING_QUOTE_CRITERIA', 'מחירי המשלוח תקפים לכתובת אותה הכנסת');
  
// multiple product add to cart
  define('TEXT_PRODUCT_LISTING_MULTIPLE_ADD_TO_CART', 'הוסף: ');
  define('TEXT_PRODUCT_ALL_LISTING_MULTIPLE_ADD_TO_CART', 'הוסף: ');
  define('TEXT_PRODUCT_FEATURED_LISTING_MULTIPLE_ADD_TO_CART', 'הוסף: ');
  define('TEXT_PRODUCT_NEW_LISTING_MULTIPLE_ADD_TO_CART', 'הוסף: ');
  //moved SUBMIT_BUTTON_ADD_PRODUCTS_TO_CART to button_names.php as BUTTON_ADD_PRODUCTS_TO_CART_ALT
// discount qty table
define('TEXT_HEADER_DISCOUNT_PRICES_PERCENTAGE', 'Qty Discounts off Price');
define('TEXT_HEADER_DISCOUNT_PRICES_ACTUAL_PRICE', 'Qty Discounts New Price');
define('TEXT_HEADER_DISCOUNT_PRICES_AMOUNT_OFF', 'Qty Discounts off Price');
define('TEXT_FOOTER_DISCOUNT_QUANTITIES', '* Discounts may vary based on Options above');
  define('TEXT_HEADER_DISCOUNTS_OFF', 'Qty Discounts Unavailable ...');

// sort order titles for dropdowns
  define('PULL_DOWN_ALL_RESET','- RESET - ');
define('TEXT_INFO_SORT_BY_PRODUCTS_NAME', 'שם המוצר');
define('TEXT_INFO_SORT_BY_PRODUCTS_NAME_DESC', 'שם המוצר בסדר הפוך');
define('TEXT_INFO_SORT_BY_PRODUCTS_PRICE', 'מחיר מנמוך עד גבוה');
define('TEXT_INFO_SORT_BY_PRODUCTS_PRICE_DESC', 'מחיר מגבוה עד נמוך');
define('TEXT_INFO_SORT_BY_PRODUCTS_MODEL', 'דגם');
define('TEXT_INFO_SORT_BY_PRODUCTS_DATE_DESC', 'תאריך הוספה מחדש לישן');
define('TEXT_INFO_SORT_BY_PRODUCTS_DATE', 'תאריך הוספה מישן לחדש');
define('TEXT_INFO_SORT_BY_PRODUCTS_SORT_ORDER', 'ברירת מחדל');

//added for Rich Text / Email Mod
 define('ENTRY_EMAIL_PREFERENCE','מנוי לעיתון');
  define('TABLE_HEADING_DOWNLOAD_COUNT', 'נשאר');
  define('HEADING_DOWNLOAD', 'To download your files click the download button and choose "Save to Disk" from the popup menu.');
  define('TABLE_HEADING_DOWNLOAD_FILENAME','שם קובץ');
  define('TABLE_HEADING_PRODUCT_NAME','שם מוצר');
  define('TABLE_HEADING_BYTE_SIZE','גודל קובץ');
  define('TEXT_DOWNLOADS_UNLIMITED', 'לא מוגבל');
  define('TEXT_DOWNLOADS_UNLIMITED_COUNT', '--- *** ---');

// misc
  define('COLON_SPACER', ':&nbsp;&nbsp;');

// table headings for cart display and upcoming products
  define('TABLE_HEADING_QUANTITY', 'כמות');
  define('TABLE_HEADING_PRODUCTS', 'שם מוצר');
  define('TABLE_HEADING_TOTAL', 'סה"כ');

// create account - login shared
  define('TABLE_HEADING_PRIVACY_CONDITIONS', 'הצהרת פרטיות');
  define('TEXT_PRIVACY_CONDITIONS_DESCRIPTION', 'בסימון תיבה זו הינך מסכים להצהרת הפרטיות של האתר. הצהרת הפרטיות ניתנת לצפייה בלינק הבא  <a href="' . zen_href_link(FILENAME_PRIVACY, '', 'SSL') . '"><span class="pseudolink">here</span></a>.');
  define('TEXT_PRIVACY_CONDITIONS_CONFIRM', 'קראתי והסכמתי להצרת הפרטיות של האתר.');
  define('TABLE_HEADING_ADDRESS_DETAILS', 'כתובת');
  define('TABLE_HEADING_PHONE_FAX_DETAILS', 'פרטי יצירת קשר נוספים');
  define('TABLE_HEADING_DATE_OF_BIRTH', 'תאריך לידה');
  define('TABLE_HEADING_LOGIN_DETAILS', 'פרטי התחברות');
  define('TABLE_HEADING_REFERRAL_DETAILS', 'האם מישהו הפנה אתך אלינו?');

  define('ENTRY_EMAIL_PREFERENCE','מידע על אימייל ואיגרת מידע');
  define('ENTRY_EMAIL_HTML_DISPLAY','HTML');
  define('ENTRY_EMAIL_TEXT_DISPLAY','TEXT-Only');
  define('EMAIL_SEND_FAILED','שגיאה: לא הצליח לשלוח אימייל ל: "%s" <%s> עם נושא: "%s"');

  define('DB_ERROR_NOT_CONNECTED', 'שגיאה - לא הצליח לתקשר עם בסיס הנתונים');

// EZ-PAGES Alerts
  define('TEXT_EZPAGES_STATUS_HEADER_ADMIN', 'WARNING: EZ-PAGES HEADER - On for Admin IP Only');
  define('TEXT_EZPAGES_STATUS_FOOTER_ADMIN', 'WARNING: EZ-PAGES FOOTER - On for Admin IP Only');
  define('TEXT_EZPAGES_STATUS_SIDEBOX_ADMIN', 'WARNING: EZ-PAGES SIDEBOX - On for Admin IP Only');

// extra product listing sorter
  define('TEXT_PRODUCTS_LISTING_ALPHA_SORTER', '');
  define('TEXT_PRODUCTS_LISTING_ALPHA_SORTER_NAMES', 'פריטים שמתחילים ב ...');
  define('TEXT_PRODUCTS_LISTING_ALPHA_SORTER_NAMES_RESET', '-- נקה --');

///////////////////////////////////////////////////////////
// include email extras
  if (file_exists(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir . '/' . FILENAME_EMAIL_EXTRAS)) {
    $template_dir_select = $template_dir . '/';
  } else {
    $template_dir_select = '';
  }
  require_once(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir_select . FILENAME_EMAIL_EXTRAS);

// include template specific header defines
  if (file_exists(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir . '/' . FILENAME_HEADER)) {
    $template_dir_select = $template_dir . '/';
  } else {
    $template_dir_select = '';
  }
  require_once(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir_select . FILENAME_HEADER);

// include template specific button name defines
  if (file_exists(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir . '/' . FILENAME_BUTTON_NAMES)) {
    $template_dir_select = $template_dir . '/';
  } else {
    $template_dir_select = '';
  }
  require_once(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir_select . FILENAME_BUTTON_NAMES);

// include template specific icon name defines
  if (file_exists(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir . '/' . FILENAME_ICON_NAMES)) {
    $template_dir_select = $template_dir . '/';
  } else {
    $template_dir_select = '';
  }
  require_once(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir_select . FILENAME_ICON_NAMES);

// include template specific other image name defines
  if (file_exists(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir . '/' . FILENAME_OTHER_IMAGES_NAMES)) {
    $template_dir_select = $template_dir . '/';
  } else {
    $template_dir_select = '';
  }
  require_once(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir_select . FILENAME_OTHER_IMAGES_NAMES);

// credit cards
  if (file_exists(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir . '/' . FILENAME_CREDIT_CARDS)) {
    $template_dir_select = $template_dir . '/';
  } else {
    $template_dir_select = '';
  }
  require_once(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir_select. FILENAME_CREDIT_CARDS);

// include template specific whos_online sidebox defines
  if (file_exists(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir . '/' . FILENAME_WHOS_ONLINE . '.php')) {
    $template_dir_select = $template_dir . '/';
  } else {
    $template_dir_select = '';
  }
  require_once(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir_select . FILENAME_WHOS_ONLINE . '.php');

// include template specific meta tags defines
  if (file_exists(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir . '/meta_tags.php')) {
    $template_dir_select = $template_dir . '/';
  } else {
    $template_dir_select = '';
  }
  require_once(DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . $template_dir_select . 'meta_tags.php');

// END OF EXTERNAL LANGUAGE LINKS
?>
