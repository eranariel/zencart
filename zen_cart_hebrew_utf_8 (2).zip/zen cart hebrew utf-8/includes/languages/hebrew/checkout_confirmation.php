<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: checkout_confirmation.php 4067 2006-08-06 07:26:21Z drbyte $
 */

define('NAVBAR_TITLE_1', 'תהליך הרכישה');
define('NAVBAR_TITLE_2', 'אישור');

define('HEADING_TITLE', 'שלב 3 מתוך 3 - אישור ההזמנה');

define('HEADING_BILLING_ADDRESS', 'כתובת לחיוב');
define('HEADING_DELIVERY_ADDRESS', 'כתובת למשלוח');
define('HEADING_SHIPPING_METHOD', 'שיטת המשלוח:');
define('HEADING_PAYMENT_METHOD', 'שיטת התשלום:');
define('HEADING_PRODUCTS', 'תכולת סל קניות');
define('HEADING_TAX', 'מס');
define('HEADING_ORDER_COMMENTS', 'הערות או הוראות מיוחדות');
// no comments entered
define('NO_COMMENTS_TEXT', 'אין');
define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', '<strong>שלב אחרון</strong>');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', '- המשך לסיום ההזמנה. תודה שקניתם אצלנו!');

define('OUT_OF_STOCK_CAN_CHECKOUT', 'פריטים המסומנים עם ' . STOCK_MARK_PRODUCT_OUT_OF_STOCK . ' אינם במלאי.<br />ירשמו ברשימת ההמתנה למוצר.');
?>