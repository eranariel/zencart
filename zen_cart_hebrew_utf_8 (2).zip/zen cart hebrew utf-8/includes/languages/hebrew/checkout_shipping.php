<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: checkout_shipping.php 4042 2006-07-30 23:05:39Z drbyte $
 */

define('NAVBAR_TITLE_1', 'תהליך הרכישה');
define('NAVBAR_TITLE_2', 'סוג המשלוח');

define('HEADING_TITLE', 'שלב 1 מתוך 3 - פרטי המשלוח');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'כתובת למשלוח');
define('TEXT_CHOOSE_SHIPPING_DESTINATION', 'המוצרים אשר הזמנת ישלחו לכתובת זו.');
define('TITLE_SHIPPING_ADDRESS', 'כתובת למשלוח:');

define('TABLE_HEADING_SHIPPING_METHOD', 'סוג המשלוח');
define('TEXT_CHOOSE_SHIPPING_METHOD', 'בחר סוג משלוח מועדף.');
define('TITLE_PLEASE_SELECT', 'בחר');
define('TEXT_ENTER_SHIPPING_INFORMATION', 'סוג משלוח זה הינו היחידי הקיים כרגע.');
define('TITLE_NO_SHIPPING_AVAILABLE', 'לא זמין כרגע');
define('TEXT_NO_SHIPPING_AVAILABLE','<span class="alert">מצטערים, כרגע אנחנו לא שולחים לאיזורך.</span><br />אנא צור קשר על מנת למצוא סידור אחר.');

define('TABLE_HEADING_COMMENTS', 'הערות או הוראות מיוחדות');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'המשך לשלב 2');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', '- בחירת סוג התשלום.');

// when free shipping for orders over $XX.00 is active
  define('FREE_SHIPPING_TITLE', 'משלוח חינם');
  define('FREE_SHIPPING_DESCRIPTION', 'משלוח חינם להזמנות מעל %s');
?>
