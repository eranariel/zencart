<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// $Id: discount_coupon.php 4591 2006-09-23 04:25:15Z ajeh $
//

define('NAVBAR_TITLE', 'קופוני הנחה');
define('HEADING_TITLE', 'קופוני הנחה');

define('TEXT_INFORMATION', 'מידע נוסף בנושא קופוני הנחה');
define('TEXT_COUPON_FAILED', '<span class="alert important">%s</span> נראה כקוד קופון לא קביל. אנא נסה/י להקלידו בשנית.');

define('HEADING_COUPON_HELP', 'עזרה בנושא קופוני הנחה');
define('TEXT_CLOSE_WINDOW', 'סגור [x]');
define('TEXT_COUPON_HELP_HEADER', '<p class="bold">קוד הקופון שהקשת הוא עבור ');
define('TEXT_COUPON_HELP_NAME', '\'%s\'. </p>');
define('TEXT_COUPON_HELP_FIXED', '');
define('TEXT_COUPON_HELP_MINORDER', '');
define('TEXT_COUPON_HELP_FREESHIP', '');
define('TEXT_COUPON_HELP_DESC', '<p><span class="bold">הנחה:</span> %s</p><p class="smallText">ייתכנו הגבלות נוספות. אנא ראה למטה מידע נוסף.</p>');
define('TEXT_COUPON_HELP_DATE', '<p>קופון זה תקף בין %s ל %s</p>');
define('TEXT_COUPON_HELP_RESTRICT', '<p class="biggerText bold">הגבלות קופון הנחה</p>');
define('TEXT_COUPON_HELP_CATEGORIES', '<p class="bold">הגבלת קטגוריות:</p>');
define('TEXT_COUPON_HELP_PRODUCTS', '<p class="bold">הגבלת מוצרים:</p>');
define('TEXT_ALLOW', 'תקף');
define('TEXT_DENY', 'לא תקף');
define('TEXT_NO_CAT_RESTRICTIONS', '<p>קופון זה תקף לכל הקטגוריות.</p>');
define('TEXT_NO_PROD_RESTRICTIONS', '<p>קופון זה תקף לכל המוצרים.</p>');
define('TEXT_CAT_ALLOWED', ' (תקף על קטגוריה זו)');
define('TEXT_CAT_DENIED', ' (לא תקף על קטגוריה זו)');
define('TEXT_PROD_ALLOWED', ' (תקף למוצר זה)');
define('TEXT_PROD_DENIED', ' (לא תקף על מוצר זה)');
// gift certificates cannot be purchased with Discount Coupons
define('TEXT_COUPON_GV_RESTRICTION','<p class="smallText">קופוני הנחה לא יהיו תקפים לרכישת ' . TEXT_GV_NAMES . '. מוגבל לקופון אחד לכל הזמנה.</p>');

define('TEXT_DISCOUNT_COUPON_ID_INFO', 'חפש קופון הנחה ... ');
define('TEXT_DISCOUNT_COUPON_ID', 'הקוד שלך: ');

define('TEXT_COUPON_GV_RESTRICTION_ZONES', 'הגבלת כתובת חיוב פעילה.');
?>