<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// $Id: download_time_out.php 1969 2005-09-13 06:57:21Z drbyte $
//

define('NAVBAR_TITLE', 'ההורדה שלך ...');
define('HEADING_TITLE', 'ההורדה שלך ...');

define('TEXT_INFORMATION', 'מתנצלים אך ההורדה שלך לא תקפה.<br /><br />
  אם יש לך הורדות אחרות וברצונך להוריד אותן,
  אנא כנס <a href="' . zen_href_link(FILENAME_ACCOUNT, '', 'SSL') . '">לחשבונך</a>ובדוק את ההזמנה.<br /><br />
  או, אם נראה לך שיש בעיה עם הזמנתך, אנא <a href="' . zen_href_link(FILENAME_CONTACT_US) . '">צור קשר</a> <br /><br />
  תודה לך!
  ');
?>