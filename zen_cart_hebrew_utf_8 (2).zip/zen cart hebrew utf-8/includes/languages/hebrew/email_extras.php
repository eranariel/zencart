<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: email_extras.php 7161 2007-10-02 10:58:34Z drbyte $
 */

// office use only
  define('OFFICE_FROM','נשלח מ:');
  define('OFFICE_EMAIL','מכתובת:');

  define('OFFICE_SENT_TO','נשלח אל:');
  define('OFFICE_EMAIL_TO','לכתובת:');

  define('OFFICE_USE','לשימוש משרד בלבד:');
  define('OFFICE_LOGIN_NAME','שם משתמש:');
  define('OFFICE_LOGIN_EMAIL','כתובת אימייל:');
    define('OFFICE_LOGIN_PHONE','<strong>טלפון:</strong>');
  define('OFFICE_LOGIN_FAX','<strong>פקס:</strong>');
  define('OFFICE_IP_ADDRESS','כתובת IP:');
  define('OFFICE_HOST_ADDRESS','כתובת שרת:');
  define('OFFICE_DATE_TIME','זמן ותאריך:');
  if (!defined('OFFICE_IP_TO_HOST_ADDRESS')) define('OFFICE_IP_TO_HOST_ADDRESS', 'OFF');

// email disclaimer
  define('EMAIL_DISCLAIMER', '-----' . "\n" . 'כתובת דואר אלקטרוני זאת ניתנה לנו על ידי אחד מלקוחותינו. אם דואר זה הגיע אליך בטעות, אנא פנא לשירות לקוחות על ידי פניה לכתובת זו ' . STORE_OWNER_EMAIL_ADDRESS . "\n\n");
  define('EMAIL_SPAM_DISCLAIMER','כתובת דואר אלקטרוני זאת ניתנה לנו על ידי אחד מלקוחותינו. אם דואר זה הגיע אליך בטעות, אנא פנא לשירות לקוחות על ידי פניה לכתובת זו ' . STORE_OWNER_EMAIL_ADDRESS . "\n\n");
//define('EMAIL_SPAM_DISCLAIMER','This e-mail is sent in accordance with the US CAN-SPAM Law in effect 01/01/2004. Removal requests can be sent to this address and will be honored and respected.');
//define('EMAIL_FOOTER_COPYRIGHT','Copyright (c) ' . date('Y') . ' <a href="http://www.zen-cart.com" target="_blank">Zen Cart</a>. Powered by <a href="http://www.zen-cart.com" target="_blank">Zen Cart</a>');
  define('EMAIL_FOOTER_COPYRIGHT','Copyright (c) ' . date('Y') . ' <a href="' . zen_href_link(FILENAME_DEFAULT) . '" target="_blank">' . STORE_NAME . '</a>. Powered by <a href="http://www.zen-cart.com" target="_blank">Zen Cart</a>');
  define('TEXT_UNSUBSCRIBE', "\n\nTo unsubscribe from future newsletter and promotional mailings, simply click on the following link: \n");

// email advisory for all emails customer generate - tell-a-friend and GV send
  define('EMAIL_ADVISORY', '-----' . "\n" . 'חשוב!: למען הגנת פרטיותך, כל תכתובת הדואר בחנות זו מוקלטת וזמינה לבעלי החנות. אם דואר זה הגיע אליך בטעות, אנא פנה למחלקת שירות הלקוחות בכתובת הנ"ל: ' . STORE_OWNER_EMAIL_ADDRESS . "\n\n");

// email advisory included warning for all emails customer generate - tell-a-friend and GV send
  define('EMAIL_ADVISORY_INCLUDED_WARNING', '<strong>This messsage is included with all emails sent from this site:</strong>');


// Admin additional email subjects
  define('SEND_EXTRA_CREATE_ACCOUNT_EMAILS_TO_SUBJECT','[יצירת חשבון חדש]');
  define('SEND_EXTRA_TELL_A_FRIEND_EMAILS_TO_SUBJECT','[ספר לחבר]');
  define('SEND_EXTRA_GV_CUSTOMER_EMAILS_TO_SUBJECT','[קופון נשלח ללקוח]');
  define('SEND_EXTRA_NEW_ORDERS_EMAILS_TO_SUBJECT','[הזמנה חדשה]');
  define('SEND_EXTRA_CC_EMAILS_TO_SUBJECT','[עוד מידע על כ.אשראי] #');

// Low Stock Emails
  define('EMAIL_TEXT_SUBJECT_LOWSTOCK','אזהרה: מלאי מועט');
  define('SEND_EXTRA_LOW_STOCK_EMAIL_TITLE','דוח מלאי מועט: ');

  define('OFFICE_IP_TO_HOST_ADDRESS', 'Disabled');
?>