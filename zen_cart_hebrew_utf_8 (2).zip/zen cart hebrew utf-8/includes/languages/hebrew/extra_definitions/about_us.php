<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: about_us.php v1.3 $
 */

// this is used to display the text link in the "information" or other sidebox
define('BOX_INFORMATION_ABOUT_US', 'About Us');

?>