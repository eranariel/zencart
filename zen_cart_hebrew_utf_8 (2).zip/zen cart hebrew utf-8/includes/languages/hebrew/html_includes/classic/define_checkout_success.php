<p><strong>Checkout Success Sample Text�...</strong></p><p>A few words about the approximate shipping time or your processing policy would be put here. </p>
<p>This section of text is from the Define Pages Editor located under Tools in the Admin.</p>
<p>This file is located in<code> /languages/english/html_includes/classic/</code></p>
<p><strong>NOTE: Always backup the files in<code> /languages/english/html_includes/your_template</code></strong></p>