<p><strong>Page 2 Sample Text�...</strong></p>
<p>This section of text is from the Define Pages Editor located under Tools in the Admin.</p>
<p>To remove this section of the text, delete it from the Define Pages Editor.</p>