<div id="home-text">
<center>
<a href="http://www.youtube.com/user/ZenCartEasyHelp" target="_blank"><img src="http://www.picaflor-azul.com/pica/images/subscribe-sm.png" class="subscribe-sm" alt="subscribe to Zen Cart Easy Help Youtube Channel" /></a>
</center>
<p>
Read the hampshire_cammie_readme.html for full, step by step detailed installation instructions with links to videos for each step.
</p>
<p>
Once your site is ready to go live, please come and promote your site by uploading a screen shot of your store to our facebook fan gallery (you can do this via the wall).  Be sure to include your store url and what you sell in the comments so that our huge fan base can find you.
</p>
<p align="center">
<a href="http://www.facebook.com/Custom.Zen.Cart.Design" target="blank"><img src="http://www.picaflor-azul.com/pica/images/promote.png" class="promote" alt="Promote your site on our Facebook Page" /></a>
</p>
<p>
This content is located in the file at: /languages/english/html_includes/hampshire_cammie/define_main_page.php
</p>
<p>
You can quickly edit this content via Admin->Tools->Define Pages Editor, and select define_main_page from the pulldown.
</p>
</div>	
