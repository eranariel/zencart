<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: ot_coupon.php 6099 2007-04-01 10:22:42Z wilt $
 */

 define('MODULE_ORDER_TOTAL_COUPON_TITLE', 'קופוני הנחה');
 define('MODULE_ORDER_TOTAL_COUPON_HEADER', TEXT_GV_NAMES . '/קופוני הנחה');
 define('MODULE_ORDER_TOTAL_COUPON_DESCRIPTION', 'קופוני הנחה');
 define('MODULE_ORDER_TOTAL_COUPON_TEXT_ENTER_CODE', TEXT_GV_REDEEM);
 define('MODULE_ORDER_TOTAL_COUPON_HEADER', TEXT_GV_NAMES . '/קופוני הנחה');
 define('SHIPPING_NOT_INCLUDED', ' [משלוח לא כלול]');
 define('TAX_NOT_INCLUDED', ' [מס לא כלול]');
 define('IMAGE_REDEEM_VOUCHER', 'פדה קופון');
 define('MODULE_ORDER_TOTAL_COUPON_REDEEM_INSTRUCTIONS', '<p>אנא הכנס את קוד קופון ההנחה. סכום ההנחה ינוכה מהסכום הסופי לאחר שתלחץ על המשך.</p><p>לתשומת לבך: ניתן להשתמש בקופון אחד לכל הזמנה.</p>');
 define('MODULE_ORDER_TOTAL_COUPON_TEXT_CURRENT_CODE', 'קוד הקופון הנוכחי הוא: ');
 define('MODULE_ORDER_TOTAL_COUPON_REMOVE_INSTRUCTIONS', '<p>להסרת השובר הקלד REMOVE ולחץ אנטר</p>');
 define('TEXT_REMOVE_REDEEM_COUPON', 'קופון הנחה הוסר לבקשתך!');
 define('MODULE_ORDER_TOTAL_COUPON_INCLUDE_ERROR', ' Setting Include tax = true, should only happen when recalculate = None');
?>