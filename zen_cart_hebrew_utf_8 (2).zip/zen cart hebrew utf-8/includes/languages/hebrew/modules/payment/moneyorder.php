<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// $Id: moneyorder.php 1969 2005-09-13 06:57:21Z drbyte $
//

  define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE', 'ציק או הפקדת מזומן');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION', 'רשום את הצ\'ק לפקודת <br />'. MODULE_PAYMENT_MONEYORDER_PAYTO.'<br /><br />'.'הינכם מוזמנים להפקיד מזומנים בכל סניף הדואר לחשבון <b>797857</b> של בנק הדואר או לשלוח את הצ\'ק אל:<br /><br />' . nl2br(STORE_NAME_ADDRESS) . '<br /><br />' . 'הזמנתך לא תשלח עד אשר לא נקבל את התשלום.');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_EMAIL_FOOTER', "רשום את הצ'ק לפקודת: \n'. MODULE_PAYMENT_MONEYORDER_PAYTO.'\n\n'.'\nהינכם מוזמנים להפקיד מזומנים בכל סניף הדואר לחשבון <b>797857</b> של בנק הדואר או לשלוח את הצ\'ק אל:\n\n" . STORE_NAME_ADDRESS . "\n\n" . 'הזמנתך לא תשלח עד אשר לא נקבל את התשלום.');
?>
