<?php
/*
  Version 2.04 for MS2 and earlier

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002, 2003 Steve Fatula of Fatula Consulting
  compconsultant@yahoo.com
modified to work with zencart and made graphically acceptable by fedex identity, fedex legal and fedex third party applications.
Tony Corbett
merlin@realm-of-merlin.com
  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_FEDEX_EXPRESS_TEXT_TITLE', 'FedEx Express');
define('MODULE_SHIPPING_FEDEX_EXPRESS_TEXT_TITLE1', '');
define('MODULE_SHIPPING_FEDEX_EXPRESS_TEXT_DESCRIPTION', 'Federal Express<br><br>You will need to have registered an account with FedEx and proper approval from FedEx identity to use this module. Please see the README.TXT file for other requirements.');
?>
