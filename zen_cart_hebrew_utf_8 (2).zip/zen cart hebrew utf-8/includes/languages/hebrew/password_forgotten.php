<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: password_forgotten.php 3086 2006-03-01 00:40:57Z drbyte $
 */

define('NAVBAR_TITLE_1', 'התחברות');
define('NAVBAR_TITLE_2', 'סיסמה נשכחה');

define('HEADING_TITLE', 'שכחת סיסמה ?');

define('TEXT_MAIN', 'הכנס כתובת דואר אלקטרוני איתה נרשמת ואנו נשלח אליה את הסיסמה');

define('TEXT_NO_EMAIL_ADDRESS_FOUND', 'כתובת הדואר אותה היזנת לא קיימת במאגר. אנא בדוק את תקינות הכתובת ונסה שנית.');

define('EMAIL_PASSWORD_REMINDER_SUBJECT', STORE_NAME . ' - סיסמה חדשה');
define('EMAIL_PASSWORD_REMINDER_BODY', 'סיסמתך היא  %s' . "\n\n");

define('SUCCESS_PASSWORD_SENT', 'סיסמה חדשה נשלחה.');
?>