<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: product_free_shipping_info.php 6371 2007-05-25 19:55:59Z ajeh $
 */

define('TEXT_PRODUCT_NOT_FOUND', 'מצטערים, המוצר לא נמצא');
define('TEXT_CURRENT_REVIEWS', 'ביקורות נוכחיות:');
define('TEXT_MORE_INFORMATION', 'למידע נוסף, אנא הכנס <a href="%s" target="_blank">לדף המוצר</a>.');
define('TEXT_DATE_ADDED', 'מוצר זה נוסף לקטלוג ב %s.');
define('TEXT_DATE_AVAILABLE', '<font color="#ff0000">מוצר זה יהיה במלאי ב %s.</font>');
define('TEXT_ALSO_PURCHASED_PRODUCTS', 'לקוחות שרכשו מוצר זה גם רכשו...');
define('TEXT_PRODUCT_OPTIONS', '<strong>אנא בחר/י:</strong>');
define('TEXT_PRODUCT_MANUFACTURER', 'מיוצר על ידי: ');
define('TEXT_PRODUCT_WEIGHT', 'משקל משלוח: ');
define('TEXT_PRODUCT_QUANTITY', ' יחידות במלאי');
define('TEXT_PRODUCT_MODEL', 'דגם: ');



// previous next product
define('PREV_NEXT_PRODUCT', 'מוצר ');
define('PREV_NEXT_FROM', ' מ ');
define('IMAGE_BUTTON_PREVIOUS','מוצר קודם');
define('IMAGE_BUTTON_NEXT','מוצר הבא');
define('IMAGE_BUTTON_RETURN_TO_PRODUCT_LIST','בחזרה לרשימת המוצרים');

// missing products
//define('TABLE_HEADING_NEW_PRODUCTS', 'New Products For %s');
//define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Upcoming Products');
//define('TABLE_HEADING_DATE_EXPECTED', 'Date Expected');

define('TEXT_ATTRIBUTES_PRICE_WAS',' [היה: ');
define('TEXT_ATTRIBUTE_IS_FREE',' עכשיו הוא: חינם]');
define('TEXT_ONETIME_CHARGE_SYMBOL', ' *');
define('TEXT_ONETIME_CHARGE_DESCRIPTION', ' ייתכן חיוב חד פעמי');
define('TEXT_ATTRIBUTES_QTY_PRICE_HELP_LINK','קיימת הנחת כמות');
define('ATTRIBUTES_QTY_PRICE_SYMBOL', zen_image(DIR_WS_TEMPLATE_ICONS . 'icon_status_green.gif', TEXT_ATTRIBUTES_QTY_PRICE_HELP_LINK, 10, 10) . '&nbsp;');
define('ATTRIBUTES_PRICE_DELIMITER_PREFIX', ' ( ');
define('ATTRIBUTES_PRICE_DELIMITER_SUFFIX', ' )');
define('ATTRIBUTES_WEIGHT_DELIMITER_PREFIX', ' (');
define('ATTRIBUTES_WEIGHT_DELIMITER_SUFFIX', ') ');

?>