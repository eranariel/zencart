<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: product_reviews_write.php 3159 2006-03-11 01:35:04Z drbyte $
 */

define('NAVBAR_TITLE', 'ביקורות');

define('SUB_TITLE_FROM', 'נכתב על ידי:');
define('SUB_TITLE_REVIEW', 'אנא אמור מה דעתך על המוצר ושתף אותה עם כולם.אנא שים לב כי הנך מתמקד במוצר עצמו.');
define('SUB_TITLE_RATING', 'בחר דירוג למוצר. כוכב אחד זה הגרוע ביותר ו-5 כוכבים זה הכי טוב.');

define('TEXT_NO_HTML', '<strong>הערה:</strong>  תגי HTML לא נתמכים.');
define('TEXT_BAD', 'גרוע');
define('TEXT_GOOD', 'טוב');
define('TEXT_PRODUCT_INFO', '');

define('TEXT_APPROVAL_REQUIRED', '<strong>הערה:</strong>  ביקורות דורשות אישור לפני הצגתן באתר');

define('EMAIL_REVIEW_PENDING_SUBJECT','ביקורות הממתינות לאישור: %s');
define('EMAIL_PRODUCT_REVIEW_CONTENT_INTRO','ביקורת למוצר %s התקבלה ודורשת את אישורך.'."\n\n");
define('EMAIL_PRODUCT_REVIEW_CONTENT_DETAILS','פרטי ביקורת: %s');

?>