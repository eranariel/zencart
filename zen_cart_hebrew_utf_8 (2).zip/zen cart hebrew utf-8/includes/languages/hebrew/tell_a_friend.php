<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: tell_a_friend.php 3159 2006-03-11 01:35:04Z drbyte $
 */

define('NAVBAR_TITLE', 'ספר לחבר');

define('HEADING_TITLE', 'ספר לחבר אודות \'%s\'');

define('FORM_TITLE_CUSTOMER_DETAILS', 'פרטיך');
define('FORM_TITLE_FRIEND_DETAILS', 'פרטי החבר/ה');
define('FORM_TITLE_FRIEND_MESSAGE', 'המסר שלך');

define('FORM_FIELD_CUSTOMER_NAME', 'השם שלך:');
define('FORM_FIELD_CUSTOMER_EMAIL', 'האימייל שלך:');
define('FORM_FIELD_FRIEND_NAME', 'השם של החבר/ה:');
define('FORM_FIELD_FRIEND_EMAIL', 'כתובת המייל של החבר/ה:');

define('EMAIL_SEPARATOR', '----------------------------------------------------------------------------------------');

define('TEXT_EMAIL_SUCCESSFUL_SENT', 'האימייל לגבי <strong>%s</strong> נשלח בהצלחה ל <strong>%s</strong>.');

define('TEXT_EMAIL_SUBJECT', '%s שלח/ה לך הודעה לגבי %s. כדאי שתראה/י');
define('TEXT_EMAIL_INTRO', 'היי %s!' . "\n\n" . '%s, חשב/ה שתתעניין/י במוצר %s מ%s.');

define('EMAIL_TELL_A_FRIEND_MESSAGE','%s שלח/ה מסר ש...');

define('EMAIL_TEXT_HEADER','הודעה חשובה!');

define('TEXT_EMAIL_LINK', 'לצפייה במוצר, לחץ/י על הקישור למטה או העתק הדבק לתוך הדפדפן:' . "\n\n" . '%s');
define('TEXT_EMAIL_SIGNATURE', 'בברכה,' . "\n\n" . '%s');
define('EMAIL_TEXT_GREET', 'היי %s!' . "\n\n");

define('ERROR_TO_NAME', 'שגיאה: שם החבר/ה לא יכול להיות ריק.');
define('ERROR_TO_ADDRESS', 'שגיאה: אימייל החבר/ה נראה לא תקין. אנא תקן/י אותו.');
define('ERROR_FROM_NAME', 'שגיאה: שמך לא יכול להיות ריק.');
define('ERROR_FROM_ADDRESS', 'שגיאה: כתובת המייל שלך לא יכולה להיות ריקה. אנא תקן/י אותו.');
?>
